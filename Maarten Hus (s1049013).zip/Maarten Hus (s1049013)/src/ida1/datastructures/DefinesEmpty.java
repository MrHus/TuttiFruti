package ida1.datastructures;

/**
 *
 * @author maartenhus
 */
public interface DefinesEmpty
{
	public boolean isEmpty();
}
